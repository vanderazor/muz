package koneksi;
import java.sql.*;

public class koneksi {
    private Connection koneksi;
    public Connection connect(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Koneksi Berhasil! Mantap!");     
        }
        catch(ClassNotFoundException ex){
            System.out.println("Yah Koneksi Gagal"+ex);
        }
        String url = "jdbc:mysql://localhost/aplikasi_kamarhotel";
        try{
            koneksi = DriverManager.getConnection(url,"root","");
            System.out.println("Koneksi Database Berhasil!");
        }
        catch (SQLException ex){
            System.out.println("Yah Koneksi Database Gagal"+ex);
        }
        return koneksi;
    }
}